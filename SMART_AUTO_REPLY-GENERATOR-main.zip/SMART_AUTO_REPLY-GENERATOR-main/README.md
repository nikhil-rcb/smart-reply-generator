# SMART_AUTO_REPLY-GENERATOR
ChatGPT said: A smart auto-reply generator for WhatsApp and Email that uses AI and tone detection to suggest context-aware replies. Built with React, Tailwind CSS, and JSON-based data handling for dynamic, user-friendly messaging automation.
